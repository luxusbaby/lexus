import Vue from 'vue';
 
import InfiniteScroll from 'v-infinite-scroll';
 

Vue.use(InfiniteScroll);